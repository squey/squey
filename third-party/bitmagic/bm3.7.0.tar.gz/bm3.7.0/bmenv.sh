#/bin/sh
# This script sets environment for building project.
# Execute this using . command like this:
# >. bmenv.sh
PROJECT_DIR=`pwd`; export PROJECT_DIR

echo Base project directory $PROJECT_DIR
